package com.example.aquib.myapplicationgenerics;

/**
 * Created by Aquib on 3/24/2017.
 *
 */

 class BeanClass {

    private String Name;
    private int Number;
    private boolean Gender;

    //it's the constructor that i have commented for the code without constructor.
    //if u need the code for constructor just remove the comment.

   /* public BeanClass(String name, int number, boolean gender) {
        Name = name;
        Number = number;
        Gender = gender;
    }*/

    String getName() {
        return Name;
    }

     void setName(String name) {
        Name = name;
    }

     int getNumber() {
        return Number;
    }

     void setNumber(int number) {
        Number = number;
    }

     boolean getGender() {
        return Gender;
    }

     void setGender(boolean gender) {
        Gender = gender;
    }


}
