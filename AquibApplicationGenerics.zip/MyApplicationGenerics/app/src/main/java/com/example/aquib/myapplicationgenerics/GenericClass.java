package com.example.aquib.myapplicationgenerics;

import android.content.Context;
import android.widget.Toast;

/**
 * Created by Aquib on 3/23/2017.
 *
 */

public class GenericClass<T> {

    //T is type;

   private T ob;       //in case of integer, on complilation it be, int ob;mean ob of type integer

    GenericClass(T o) {
        ob = o;             // in this constructor ob be intialised by the paramerterised value where it is instantiated from.
    }

    T getob() {
        return ob;         //  in this method it will return the value of ob from whenever this method be called.
    }

    void showType() {      //in this method it will print the Type of ob.
        System.out.println("Type of T is " + ob.getClass().getName());
    }


    String showTypeOfT()
    {
        return ob.getClass().getName();
    }
}
