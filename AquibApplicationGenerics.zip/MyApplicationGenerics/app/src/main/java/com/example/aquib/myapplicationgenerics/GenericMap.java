package com.example.aquib.myapplicationgenerics;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Aquib on 3/24/2017.
 *
 */

// This also can be used to store values

 class GenericMap {

   String MapValue()
   {
       Map<String, String> map = new HashMap<>();
       map.put ("key1", "value1");
       map.put ("key2", "value2");
       return map.get("key1");

   }

   String MapKeyValue()
   {
       Map<Integer, String> map = new HashMap<>();
       map.put (1, "value1");
       map.put (2, "value2");
       return map.get(2);
   }

}
