package com.example.aquib.myapplicationgenerics;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Aquib on 3/23/2017.
 *
 * Abstract class has been used to better understand Abstract class and its features
 *
 */

public abstract class GenericsAbstractClass extends AppCompatActivity {

    abstract int value();

    void generics(Context context,int value)
    {
        List<String> list = new ArrayList<>();
        list.add("hello generics");
        String s = list.get(0);   // no cast

        Toast.makeText(context, s+value, Toast.LENGTH_LONG).show();
    }

    void withoutGenerics(Context context,int value)
    {
        List list = new ArrayList();
        list.add("without generics");
        String s = (String) list.get(0);

        Toast.makeText(context, s+value, Toast.LENGTH_LONG).show();

    }


}
