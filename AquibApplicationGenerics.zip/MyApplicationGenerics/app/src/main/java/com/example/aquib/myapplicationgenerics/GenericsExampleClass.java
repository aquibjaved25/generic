package com.example.aquib.myapplicationgenerics;

import android.content.Context;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Aquib on 3/23/2017.
 *
 * it's normal class example
 *
 */

 class GenericsExampleClass {

        private Context context;

     GenericsExampleClass(Context context) {
        this.context = context;
    }

       void generics()
    {
        List<String> list = new ArrayList<>();
        list.add("hello generics");
        String s = list.get(0);   // no cast

        Toast.makeText(context, s, Toast.LENGTH_LONG).show();
    }

      void withoutGenerics()
    {
        List list = new ArrayList();
        list.add("without generics");
        String s = (String) list.get(0);

        Toast.makeText(context, s, Toast.LENGTH_LONG).show();

    }
}
