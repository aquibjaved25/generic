package com.example.aquib.myapplicationgenerics;

 /*
    Why generics?

 1. Stronger type checks at compile time.
    A Java compiler applies strong type checking to generic code and issues errors if the code violates type safety.
    Fixing compile-time errors is easier than fixing runtime errors, which can be difficult to find.

 2. Elimination of casts.

 3. Enabling programmers to implement generic algorithms.
    By using generics, programmers can implement generic algorithms that work on collections of different types,
    can be customized, and are type safe and easier to read.
    */

 // Control+shift+/  For Block comment

import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends GenericsAbstractClass {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        ============================================ GenericsAbstractClass =========================================

        // this is how we create object of an abstract class.
       /* GenericsAbstractClass obj = new MainActivity();
        obj.value();

        generics(this,value());
        withoutGenerics(this,value());*/

//       ============================================ GenericsExampleClass =========================================

        /*GenericsExampleClass generic_example = new GenericsExampleClass(this);
        generic_example.generics();
        generic_example.withoutGenerics();*/

//      ============================================ GenericClass =========================================
        // Create a Gen reference for Integers.
        /*GenericClass<Integer> iOb = new GenericClass<Integer>(88);
        iOb.showType();

        // no cast is needed.
        int v = iOb.getob();
        System.out.println("value: " + v);

        // Create a Gen object for Strings.
        GenericClass<String> strOb = new GenericClass<String>("Generics Test");
        strOb.showType();

        String str = strOb.getob();
        System.out.println("value: " + str);

        //Show Type
        Toast.makeText(this, iOb.showTypeOfT(), Toast.LENGTH_SHORT).show();

        Toast.makeText(this, strOb.showTypeOfT(), Toast.LENGTH_SHORT).show();*/

//      ============================================ BeanClass with constructor =========================================

       /* BeanClass beanClass = new BeanClass("Aquib",7,true);
        BeanClass beanClass1 = new BeanClass("Javed",6,true);

        ArrayList<BeanClass> arrayList = new ArrayList<>();

        arrayList.add(beanClass);
        arrayList.add(beanClass1);

        String name = arrayList.get(0).getName();

        Toast.makeText(this, name, Toast.LENGTH_LONG).show();


        int number = arrayList.get(1).getNumber();

        Toast.makeText(this,""+ number, Toast.LENGTH_LONG).show();*/


//      ============================================ BeanClass without constructor =========================================

       /* BeanClass beanClass = new BeanClass();

        beanClass.setName("Aquib");
        beanClass.setGender(true);
        beanClass.setNumber(7);

        BeanClass beanClass1 = new BeanClass();

        beanClass1.setName("Javed");
        beanClass1.setGender(true);
        beanClass1.setNumber(8);

        ArrayList<BeanClass> arrayList = new ArrayList<>();

        arrayList.add(beanClass);
        arrayList.add(beanClass1);

        String name = arrayList.get(0).getName();

        Toast.makeText(this, name, Toast.LENGTH_LONG).show();


        int number = arrayList.get(1).getNumber();

        Toast.makeText(this,""+ number, Toast.LENGTH_LONG).show();

        boolean gender = arrayList.get(1).getGender();

        Toast.makeText(this, ""+gender, Toast.LENGTH_SHORT).show();*/

//     ============================== A Generic Class with Two Type Parameters ===============================
                                //    Boolean                                                    Boolean          true
       /* TwoTypeParametersGenericClass<Integer, String> tgObj = new TwoTypeParametersGenericClass<Integer, String>(88, "Generics");
        tgObj.showTypes();

      //boolean
        int v = tgObj.getob1();
        System.out.println("value of 1st generic: " + v);

        Toast.makeText(this, ""+v, Toast.LENGTH_SHORT).show();

        String str = tgObj.getob2();
        System.out.println("value of 2nd generic: " + str);

        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();

        Toast.makeText(this, tgObj.showTypeT(), Toast.LENGTH_SHORT).show();

        Toast.makeText(this, tgObj.showTypeV(), Toast.LENGTH_SHORT).show();*/


// ==================================Nested Generic Type =====================================================

        /*NestedGenericType nested = new NestedGenericType();

        Toast.makeText(this, nested.Nested(), Toast.LENGTH_SHORT).show();*/

// ==================================Generic Map =====================================================

        /*GenericMap genericmap = new GenericMap();

        Toast.makeText(this, genericmap.MapValue(), Toast.LENGTH_SHORT).show();
        Toast.makeText(this, genericmap.MapKeyValue(), Toast.LENGTH_SHORT).show();*/


// ================================= TwoParameterAndGenericAddedExampleClass ===========================================

        TwoParameterAndGenericAddedExampleClass<Integer, String> tgObj = new TwoParameterAndGenericAddedExampleClass<Integer, String>();
        tgObj.addValue(88, "Generics");     //used only one object to add as many times i want.
        tgObj.addValue(98,"Champ");

        TwoParameterAndGenericAddedExampleClass<String, Boolean> tgObj1 = new TwoParameterAndGenericAddedExampleClass<>();
        tgObj1.addValue("hello",true);


        Toast.makeText(this, ""+tgObj.getValue(98), Toast.LENGTH_SHORT).show();
        Toast.makeText(this, ""+tgObj1.getValue("hello"), Toast.LENGTH_SHORT).show();
    }


    @Override
    int value() {
        return 8;
    }
}
