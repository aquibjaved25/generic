package com.example.aquib.myapplicationgenerics;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Aquib on 3/24/2017.
 *
 */

                    //didn't much use of this.just found an example over here:-
                    //http://www.java2s.com/Tutorial/Java/0200__Generics/Nestedgenerictype.htm

 class NestedGenericType {

    String Nested()
    {
        List<String> listOfStrings = new ArrayList<String>();
        listOfStrings.add("Hello Nested");
        List<List<String>> listOfLists = new ArrayList<List<String>>();
        listOfLists.add(listOfStrings);
        String s = listOfLists.get(0).get(0);
        System.out.println(s); // prints "Hello again"
        return s;
    }
}
