package com.example.aquib.myapplicationgenerics;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Aquib on 3/24/2017.
 *
 */

class TwoParameterAndGenericAddedExampleClass<T,V> {
   /* private T ob1;

    private V ob2;*/
    private Map<T, V> map;

    /*TwoParameterAndGenericAddedExampleClass(T o1, V o2) {  // here i use method to get values.so removed constructor.
        ob1 = o1;       //if i used constructor for initialization then i have to create lots of objects as many times i gotta add
        ob2 = o2;       // o1 and 02.so i choose method so that i can reuse only one object as many times i want.
    }*/

    void addValue(T o1, V o2)               // here i use method to get values;
    {
        map = new HashMap<>();
        map.put(o1,o2);
    }

    V getValue(T valueasked)
    {
        return map.get(valueasked);
    }
}
