package com.example.aquib.myapplicationgenerics;

/**
 * Created by Aquib on 3/24/2017.
 *
 */

 class TwoTypeParametersGenericClass <T, V> {
   private T ob1;

    private V ob2;

    TwoTypeParametersGenericClass(T o1, V o2) {
        ob1 = o1;
        ob2 = o2;
    }

    void showTypes() {

        System.out.println("Type of T is " + ob1.getClass().getName());

        System.out.println("Type of V is " + ob2.getClass().getName());
    }

    String showTypeT()
    {
        return ob1.getClass().getName();
    }

    String showTypeV()
    {
        return ob2.getClass().getName();
    }
    T getob1() {
        return ob1;
    }

    V getob2() {
        return ob2;
    }
}
